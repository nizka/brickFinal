class Brick:
  def __init__(self, x, y):
    self.x=x
    self.y=y
    self.active = True    
  def hit_test(self, x, y):
    if self.x < x < self.x + 52 and self.y < y < self.y + 30:
        self.active=False     
  def draw(self):
    if self.active==True:
        stroke(0)
        fill(219,29,29)
        rect(self.x,self.y,(width-20)/10,30)
    else:
        stroke(50,10,227)
        fill(50,10,227)
        rect(self.x,self.y,(width-20)/10,30)
        
           
